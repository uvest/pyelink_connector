# pyelink-connector examples

You should be able to run these examples after setting up your EyeLink and installing the pyelink-connector.

To run an example activate your respective environment and execute

```python
python examplePygame.py
```

The examples first open the setup screen and afterwards implement a simple tracking task where a moving target and the current eye-positions are displayed.

## Known bugs
In the `examplePygame.py` the target may get stuck in a corner.